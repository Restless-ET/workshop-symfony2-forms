<?php

namespace DeepSpaceOne\GameBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DeepSpaceOneGameBundle extends Bundle
{
}
